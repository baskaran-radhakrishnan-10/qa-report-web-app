package com.equiniti.qa_report.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping(value="/dashboard/")
public class DashboardWebController {
	
	
	
}
