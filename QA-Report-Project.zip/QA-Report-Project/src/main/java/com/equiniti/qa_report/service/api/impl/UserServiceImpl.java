package com.equiniti.qa_report.service.api.impl;

public class UserServiceImpl {

}
