package com.equiniti.qa_report.web.controller;

public class ReportSearchWebController {

}
