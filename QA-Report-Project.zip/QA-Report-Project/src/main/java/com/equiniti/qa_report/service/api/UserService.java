package com.equiniti.qa_report.service.api;

public interface UserService {

}
